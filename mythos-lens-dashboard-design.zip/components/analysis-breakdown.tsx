"use client"

import { useState } from "react"
import { ChevronDown, Scroll, Users, Sparkles, MapPin, Quote, Flame } from "lucide-react"
import { cn } from "@/lib/utils"

interface AnalysisSection {
  id: string
  title: string
  icon: React.ElementType
  content: string
  tags: string[]
  highlight?: string
}

interface AnalysisBreakdownProps {
  isVisible: boolean
}

const mockAnalysis: AnalysisSection[] = [
  {
    id: "origin",
    title: "Epic Origin",
    icon: Scroll,
    content: "This verse emerges from the Shaivite literary tradition, specifically invoking the fearsome Tandava context. It references Shiva in his role as Mahakala - the great time, the ultimate destroyer who brings cosmic dissolution (Pralaya) at the end of each cosmic cycle.",
    tags: ["Shaivite Literature", "Shiva Tandava", "Mahakala", "Telugu Devotional"],
    highlight: "Shiva Tandava Context",
  },
  {
    id: "characters",
    title: "Mythological Figures",
    icon: Users,
    content: "The text invokes Lord Shiva (The Destroyer) in his most fierce aspect - the Mahogra Roopam (terrifying form). It also alludes to Veerabhadra, the fierce warrior avatar born from Shiva's matted locks to destroy Daksha's sacrifice, representing divine wrath made manifest.",
    tags: ["Lord Shiva", "Veerabhadra", "Rudra", "Mahakala"],
    highlight: "The Destroyer & The Fierce Warrior",
  },
  {
    id: "themes",
    title: "Recurring Themes",
    icon: Flame,
    content: "The verse explores cosmic destruction as a necessary force for renewal. The concept of Raudra Rasa (the aesthetic emotion of fury) dominates, alongside the paradox of destruction as preservation - for without dissolution, creation cannot renew. The cosmic balance between Srishti (creation) and Laya (dissolution) is central.",
    tags: ["Cosmic Destruction", "Cosmic Balance", "Divine Rage", "Raudra Rasa", "Laya"],
    highlight: "Raudra Rasa - The Aesthetic of Divine Fury",
  },
  {
    id: "symbolism",
    title: "Sacred Symbolism",
    icon: Sparkles,
    content: "Rudra-Netram (the eye of Rudra) references Shiva's third eye - the eye of wisdom and destruction that reduces Kama (desire) and the universe itself to ashes. The 'Layakaarakam' (cause of dissolution) connects to Shiva's role in the Trimurti as the necessary force of ending.",
    tags: ["Third Eye", "Rudra Netram", "Trimurti", "Cosmic Fire"],
    highlight: "The Third Eye of Dissolution",
  },
  {
    id: "geography",
    title: "Regional Tradition",
    icon: MapPin,
    content: "The Telugu linguistic markers and devotional structure place this firmly in the Andhra-Telangana Shaivite tradition. This region has a rich history of Shiva worship, with temples like Srisailam and a strong tradition of composing praise poetry (Stotras) in the local language.",
    tags: ["Telugu", "Andhra Tradition", "South Indian Shaivism", "Srisailam"],
    highlight: "Andhra-Telangana Shaivite",
  },
  {
    id: "quotation",
    title: "Parallel Verses",
    icon: Quote,
    content: "\"Jatatavigalajjala pravahapavitasthale, Galeavalambya lambitam bhujangatungamalikam\" — Opening of the Shiva Tandava Stotram by Ravana, praising Shiva's cosmic dance of destruction and creation.",
    tags: ["Tandava Stotram", "Ravana's Hymn", "Sanskrit Stotra"],
    highlight: "Shiva Tandava Stotram",
  },
]

export function AnalysisBreakdown({ isVisible }: AnalysisBreakdownProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>(["origin", "characters"])

  const toggleSection = (id: string) => {
    setExpandedSections((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    )
  }

  if (!isVisible) return null

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Analysis Breakdown</h2>
          <p className="text-sm text-muted-foreground">Mythological deconstruction complete</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full text-xs bg-primary/10 text-primary border border-primary/20">
            {mockAnalysis.length} Insights
          </span>
          <span className="px-3 py-1 rounded-full text-xs bg-green-500/10 text-green-400 border border-green-500/20">
            High Confidence
          </span>
        </div>
      </div>

      {/* Scrolling Analysis Container */}
      <div className="flex-1 overflow-auto pr-2 space-y-4 scrollbar-thin scrollbar-thumb-border scrollbar-track-transparent">
        {mockAnalysis.map((section, index) => {
          const Icon = section.icon
          const isExpanded = expandedSections.includes(section.id)

          return (
            <div
              key={section.id}
              className={cn(
                "rounded-xl glass-intense overflow-hidden transition-all duration-300",
                isExpanded && "shadow-lg shadow-primary/5"
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Section Header */}
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-primary/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-lg flex items-center justify-center transition-all",
                    isExpanded 
                      ? "bg-primary/20 text-primary" 
                      : "bg-secondary text-muted-foreground"
                  )}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className={cn(
                      "font-medium transition-colors",
                      isExpanded ? "text-primary" : "text-foreground"
                    )}>
                      {section.title}
                    </h3>
                    {section.highlight && (
                      <span className="text-xs text-muted-foreground">
                        {section.highlight}
                      </span>
                    )}
                  </div>
                </div>
                <ChevronDown
                  className={cn(
                    "w-5 h-5 text-muted-foreground transition-transform duration-300",
                    isExpanded && "rotate-180"
                  )}
                />
              </button>

              {/* Expanded Content */}
              <div
                className={cn(
                  "overflow-hidden transition-all duration-300",
                  isExpanded ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                )}
              >
                <div className="px-4 pb-4 pt-0">
                  {/* Divider line with glow */}
                  <div className="relative h-px bg-border/30 mb-4">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
                  </div>

                  {/* Content text */}
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {section.content}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {section.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1 rounded-md text-xs bg-secondary/80 text-foreground/80 border border-border/30 hover:border-primary/30 hover:text-primary transition-all cursor-default"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )
        })}

        {/* Summary Card */}
        <div className="rounded-xl glass-intense p-4 mt-6 border border-primary/20">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium text-primary mb-1">Analysis Summary</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                This text references the fierce, reality-shattering aspect of Shiva&apos;s third eye (Rudra-Netram). 
                It captures the transition from structural balance to absolute cosmic dissolution, embodying the 
                Shaivite understanding of destruction as a sacred necessity. The Telugu devotional form connects 
                to the rich Andhra tradition of Shiva worship, where the terrifying and the divine are one.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
