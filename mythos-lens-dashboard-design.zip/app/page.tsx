"use client"

import { useState, useCallback } from "react"
import { Sidebar } from "@/components/sidebar"
import { LyricInput } from "@/components/lyric-input"
import { NodeGraph } from "@/components/node-graph"
import { AnalysisBreakdown } from "@/components/analysis-breakdown"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function MythosLensDashboard() {
  const [activeView, setActiveView] = useState<"deconstructor" | "characterweb">("deconstructor")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [hasAnalysis, setHasAnalysis] = useState(false)
  const [analysisStats, setAnalysisStats] = useState({
    archetypes: 0,
    references: 0,
    traditions: 0,
    lastAnalysis: "Never",
  })

  const handleTextSubmit = useCallback((text: string) => {
    setIsAnalyzing(true)
    setHasAnalysis(false)

    // Simulate analysis with 2 second delay
    setTimeout(() => {
      setIsAnalyzing(false)
      setHasAnalysis(true)
      setAnalysisStats({
        archetypes: 8,
        references: 11,
        traditions: 1,
        lastAnalysis: "Just now",
      })
    }, 2000)
  }, [])

  const handleViewChange = useCallback((view: "deconstructor" | "characterweb") => {
    setActiveView(view)
  }, [])

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Ambient Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Top right glow */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-glow" />
        {/* Bottom left glow */}
        <div 
          className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse-glow"
          style={{ animationDelay: "2s" }}
        />
        {/* Center subtle glow */}
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl"
        />
      </div>

      {/* Sidebar */}
      <Sidebar activeView={activeView} onViewChange={handleViewChange} />

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header Bar */}
        <header className="h-16 border-b border-border/30 flex items-center justify-between px-6 bg-background/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isAnalyzing ? "bg-primary animate-pulse" : "bg-green-500"}`} />
              <span className="text-sm text-muted-foreground">
                {isAnalyzing ? "Analyzing..." : "System Active"}
              </span>
            </div>
            <div className="h-4 w-px bg-border" />
            <span className="text-sm text-muted-foreground">
              Analysis Engine v2.4
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground px-3 py-1 rounded-full bg-secondary/50 border border-border/30">
              {hasAnalysis ? "Regional: Telugu Shaivite Tradition" : "Regional: All Mythologies"}
            </span>
          </div>
        </header>

        {/* Split View Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Lyric Input */}
          <div className="w-1/2 p-6 border-r border-border/30 overflow-auto">
            <LyricInput onSubmit={handleTextSubmit} isLoading={isAnalyzing} />
          </div>

          {/* Right Panel - Dynamic Content Based on View and State */}
          <div className="w-1/2 p-6 overflow-auto">
            {isAnalyzing ? (
              <LoadingSpinner />
            ) : activeView === "deconstructor" ? (
              <AnalysisBreakdown isVisible={hasAnalysis} />
            ) : (
              <NodeGraph hasAnalysis={hasAnalysis} />
            )}

            {/* Placeholder when no analysis and on deconstructor view */}
            {!isAnalyzing && activeView === "deconstructor" && !hasAnalysis && (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                  <svg
                    className="w-10 h-10 text-primary/50"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={1.5}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Awaiting Text Input
                </h3>
                <p className="text-sm text-muted-foreground max-w-xs">
                  Paste lyrics, verses, or mythological text on the left panel and click Analyze to reveal hidden patterns.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Stats Bar */}
        <footer className="h-12 border-t border-border/30 flex items-center justify-between px-6 bg-background/50 backdrop-blur-sm">
          <div className="flex items-center gap-6 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="text-foreground font-medium">{analysisStats.archetypes}</span>
              <span>Archetypes Detected</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-foreground font-medium">{analysisStats.references}</span>
              <span>Mythological References</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-foreground font-medium">{analysisStats.traditions}</span>
              <span>Regional Traditions</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Last analysis:</span>
            <span className="text-primary">{analysisStats.lastAnalysis}</span>
          </div>
        </footer>
      </main>
    </div>
  )
}
